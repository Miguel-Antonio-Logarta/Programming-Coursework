// Project:		CIS022_F2019_Lec10c.cpp
// Author:		Mark Berrett
// Date:		November 16, 2019
// Purpose:		Lecture 10c
//				Convert struct to class
//

#include <iostream>
#include <string>								// string library
#include <fstream>								// for file input

using namespace std;							// use standard namespaces

const int NUM_RECORDS = 20;						// input file has 20 records
const int NUM_SCORES = 10;						// number of test scores in each record

struct IDStruct									// struct to hold personal identification data
{
	string strID;								// student id number
	string strLName;							// student last name
	string strFName;							// student first name
};

struct ScoresStruct								// struct to hold test score data
{
	double dScore[10];							// 10 individual test scores
	double dTotal;								// calucated sum of test scores
};

struct StudentStruct							// top struct, holds all data plus calculated grade
{
	IDStruct ID;								// sub-struct holding personal data
	ScoresStruct Scores;						// sub-struct holding test scores and average
	char Grade;									// calucated letter grade
};

int main()
{
	StudentStruct Student[NUM_RECORDS];			// array of 20 stucts to hold input file data

	ifstream inFile;
	string szSourcePath =
		"CIS022_F2019_Lec10c_data.csv";
	ofstream outFile;
	string szOutPath =
		"out.txt";

	inFile.open(szSourcePath);					// open the file

	if (inFile.is_open())						// did the file open okay?
	{
		for (int i = 0; i < NUM_RECORDS; i++)	// file has 20 rows
		{
			string strScore;					// temp string to hold file data
			double dScore;						// converted from file string
			double dSum = 0.0;					// accumulate scores

			// read 1st three fields in record
			getline(inFile, Student[i].ID.strID, ',');
			getline(inFile, Student[i].ID.strLName, ',');
			getline(inFile, Student[i].ID.strFName, ',');

			// read scores, comma delimited so will not read last field
			for (int j = 0; j < NUM_SCORES - 1; j++)// loop through all but the last score
			{
				getline(inFile, strScore, ',');		// get score
				dScore = atof(strScore.c_str());	// convert to real
				Student[i].Scores.dScore[j] = dScore;// store in struct
				dSum += dScore;						// accumulate
			}
			getline(inFile, strScore, '\n');		// get last score
			dScore = atof(strScore.c_str());		// convert to real
			Student[i].Scores.dScore[NUM_SCORES-1] = dScore;	// store in struct
			dSum += dScore;							// accumulate

			Student[i].Scores.dTotal = dSum;		// store total

			if (dSum >= 90.0)						// calc and store grade
				Student[i].Grade = 'A';
			else if (dSum >= 80.0)
				Student[i].Grade = 'B';
			else if (dSum >= 70.0)
				Student[i].Grade = 'C';
			else if (dSum >= 60.0)
				Student[i].Grade = 'D';
			else Student[i].Grade = 'F';

		}

		inFile.close();								// close input file

		outFile.open(szOutPath);					// open output file

		if (outFile.is_open())						// did file open okay
		{
			for (int i = 0; i < NUM_RECORDS; i++)			// run through array of students
			{
				outFile << "Student: " <<			// student id
					Student[i].ID.strID <<
					endl;
				outFile << "         " <<			// student name
					Student[i].ID.strLName <<
					", " <<
					Student[i].ID.strFName <<
					endl;
				outFile << "Points:  " <<			// total score
					Student[i].Scores.dTotal <<
					endl;
				outFile << "Grade:   " <<			// grade
					Student[i].Grade <<
					endl << endl;
			}

			outFile.close();						// close output file
		}

	}





	cout << endl << endl << endl;				// blank lines
}

